

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="validate.php" method="post">
	<label>Email</label>
	<input type="text" name="email"><br><br>
	<label>Password</label>
	<input type="password" name="pass"><br><br><br>
	<input type="submit" name="Sign In">
</form>
</body>
</html>

