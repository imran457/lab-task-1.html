@import url('https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap');


*{
margin: 0;
padding: 0;
box-sizing: border-box;
list-style: none;
font-family: 'Montserrat', sans-serif;

}


body{

background: lightblue;//#585c68
font-size: 14px;
line-height: 22px;
color: #555555;

}



.bold{

	font-weight: 700;
	font-size: 20px;
	text-transform: uppercase;
}




.semi_bold{

	font-weight: 500;
	font-size: 16px;
}




.resume{
width: 800px;
height:auto;
display:flex;
margin: 50px auto;

}


.resume.resume_left{
width: 280px;
background: #0bb5f4;

}